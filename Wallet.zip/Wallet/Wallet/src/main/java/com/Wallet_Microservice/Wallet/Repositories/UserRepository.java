package com.Wallet_Microservice.Wallet.Repositories;

import com.Wallet_Microservice.Wallet.Entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer> {

    Optional<User> findByEmail(String email);
    Optional<User> findByname(String name);
}